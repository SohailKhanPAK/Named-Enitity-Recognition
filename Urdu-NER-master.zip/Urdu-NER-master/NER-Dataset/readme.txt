The dataset is a chunk of the dataset retrieved from 
http://ltrc.iiit.ac.in/ner-ssea-08/index.cgi?topic=5
(Workshop on NER for South and South East Asian Languages in IJCNLP 2008 at Hyderabad, India)
 
The data is reformatted and enriched. Please refer/acknowledge in your paper/report to the original source too, if you use this data.